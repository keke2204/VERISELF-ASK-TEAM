import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import {
  Shield,
  ArrowUpRight,
  ArrowDown,
  ArrowRight,
  Search,
  Lock,
  CheckCircle2,
  Globe,
  Users,
  Sparkles,
  AlertTriangle,
  Bell,
  Database,
  Scale,
  ShieldCheck,
  CheckCircle,
  Sun,
  Moon,
  Menu,
  X,
  Heart,
} from "lucide-react";

function Brand({ inverse = false }) {
  return (
    <a
      className={`brand${inverse ? " brand--inverse" : ""}`}
      href="#top"
      aria-label="VeriSelf home"
    >
      <span className="brand__symbol" aria-hidden="true">
        <Shield size={20} strokeWidth={1.8} />
      </span>
      <span className="brand__name">
        veriself<span>.</span>
      </span>
    </a>
  );
}

const PRINCIPLES = [
  {
    icon: Shield,
    number: "01",
    title: "Signals, not certainty",
    text: "Use automated findings as a place to begin a careful review—not as proof or a final verdict.",
  },
  {
    icon: Lock,
    number: "02",
    title: "Your media, your call",
    text: "Uploads happen only after you connect a backend and submit an action. Choose sources you are authorized to review.",
  },
  {
    icon: CheckCircle2,
    number: "03",
    title: "A useful next step",
    text: "Keep matches, alerts, evidence records, and response drafts together so you can decide what to do next.",
  },
];

const STEPS = [
  {
    number: "01",
    title: "Set an identity reference",
    text: "Enroll a photo you have permission to use, then verify a selected image against it.",
  },
  {
    number: "02",
    title: "Choose a review",
    text: "Submit an authorized image, video, candidate URL, or public page for an on-demand check.",
  },
  {
    number: "03",
    title: "Review before acting",
    text: "Read the returned signals, evidence, and draft responses. You decide what happens next.",
  },
];

const FAQS = [
  {
    question: "What is Veriself?",
    answer:
      "VeriSelf is a digital-identity-defense project for everyday people. Its toolkit brings together identity references, on-demand public-page scans, media review, alerts, evidence records, response drafts, and experimental image protection.",
  },
  {
    question: "Does it continuously scan the whole internet?",
    answer:
      "No. The system performs operator-triggered scans for URLs that a user explicitly adds. It is not an invasive, continuous web monitoring service. Only submit sources you are authorized to review.",
  },
  {
    question: "Are match or forensic scores proof?",
    answer:
      "No. The source project uses development-grade biometric and media heuristics. Results can be wrong, are not calibrated probabilities, and should only guide careful human review.",
  },
  {
    question: "Does VeriSelf send legal notices for me?",
    answer:
      "No. It can prepare a response draft from a finding, but it does not send or file anything automatically. Review any draft carefully and consult qualified legal counsel for legal decisions.",
  },
  {
    question: "Can VeriSelf create a protected image today?",
    answer:
      "This preview offers signature verification and provenance inspection. Any signature feature assists in verification, while human vigilance ensures complete identity control.",
  },
  {
    question: "Where does my media go?",
    answer:
      "The site sends requests only when you interact with features or test the backend API. File uploads and analysis run locally or through your configured server.",
  },
];

const PLATFORM_MODULES = [
  {
    icon: Shield,
    number: "01",
    title: "Identity profile",
    text: "Enroll a reference portrait and compare a selected image against it.",
    href: "/identity",
  },
  {
    icon: Globe,
    number: "02",
    title: "Public-page scans",
    text: "Add a permitted public URL and start an on-demand scan when you choose.",
    href: "/monitoring",
  },
  {
    icon: Users,
    number: "03",
    title: "Candidate matches",
    text: "Review a candidate image URL against an enrolled profile—with human judgment in the loop.",
    href: "/matches",
  },
  {
    icon: Sparkles,
    number: "04",
    title: "Media forensics",
    text: "Inspect image and video indicators without treating a score as a verdict.",
    href: "/manipulation",
  },
  {
    icon: AlertTriangle,
    number: "05",
    title: "Risk findings",
    text: "See backend-reported findings and severity summaries in one place.",
    href: "/risk",
  },
  {
    icon: Bell,
    number: "06",
    title: "Alerts & triage",
    text: "Review, resolve, or dismiss reported alerts after checking their context.",
    href: "/alerts",
  },
  {
    icon: Database,
    number: "07",
    title: "Evidence records",
    text: "Inspect source details and recorded SHA-256 hashes returned by the service.",
    href: "/evidence",
  },
  {
    icon: Scale,
    number: "08",
    title: "Legal drafts",
    text: "Prepare a response draft for your own review; nothing is automatically sent.",
    href: "/legal",
  },
  {
    icon: ShieldCheck,
    number: "09",
    title: "Image signature review",
    text: "Verify an existing signature and review provenance records.",
    href: "/protection",
  },
];

function HeroArt() {
  return (
    <div
      className="hero-art"
      role="img"
      aria-label="Illustration of an image provenance signature review"
    >
      <div className="hero-art__sun" />
      <span className="hero-art__scribble hero-art__scribble--one" aria-hidden="true">
        ✳
      </span>
      <span className="hero-art__scribble hero-art__scribble--two" aria-hidden="true">
        ✳
      </span>

      <div className="reflection-card">
        <div className="reflection-card__top">
          <span className="eyebrow">IMAGE PROVENANCE</span>
          <span className="reflection-card__dots" aria-hidden="true">
            •••
          </span>
        </div>

        <div className="reflection-card__orb">
          <span />
        </div>

        <p className="reflection-card__question">
          A mark you can
          <br />
          <em>check later.</em>
        </p>

        <div className="reflection-card__line" />

        <div className="reflection-card__footer">
          <span>
            <span className="tiny-dot" /> Invisible signature
          </span>
          <ShieldCheck size={17} aria-hidden="true" />
        </div>
      </div>

      <div className="art-note">
        <span className="art-note__icon">
          <Search size={15} />
        </span>
        <span>
          Worth a closer look.
          <br />
          Never a final verdict.
        </span>
      </div>

      <span className="hero-art__caption">
        YOUR IMAGE. YOUR DECISION <ArrowDown size={13} />
      </span>
    </div>
  );
}

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [theme, setTheme] = useState(() => {
    try {
      return localStorage.getItem("veriself-theme") || "light";
    } catch {
      return "light";
    }
  });

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    try {
      localStorage.setItem("veriself-theme", theme);
    } catch {
      // ignore
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === "dark" ? "light" : "dark"));
  };

  const handleContactSubmit = (e) => {
    e.preventDefault();
    setFormSubmitted(true);
  };

  const closeMenu = () => setMobileMenuOpen(false);

  return (
    <div className="site-shell" id="top">
      {/* Top Announcement Bar */}
      <div className="announcement">
        <span className="announcement__spark">✳</span> A little space to find your
        next step{" "}
        <a href="#about">
          Meet Veriself <ArrowUpRight size={13} />
        </a>
      </div>

      {/* Sticky Header */}
      <header className="site-header">
        <div className="header-inner wrap">
          <Brand />

          <button
            className="mobile-menu-toggle"
            type="button"
            aria-label={mobileMenuOpen ? "Close navigation" : "Open navigation"}
            aria-expanded={mobileMenuOpen}
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>

          <nav
            className={`main-nav${mobileMenuOpen ? " main-nav--open" : ""}`}
            aria-label="Main navigation"
          >
            <a href="#about" onClick={closeMenu}>
              About
            </a>
            <a href="#platform" onClick={closeMenu}>
              Platform
            </a>
            <a href="#faq" onClick={closeMenu}>
              FAQs
            </a>
            <Link className="nav-cta" to="/dashboard" onClick={closeMenu}>
              Open dashboard <ArrowUpRight size={15} />
            </Link>
          </nav>

          <button
            className="theme-toggle"
            type="button"
            aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
            onClick={toggleTheme}
          >
            {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
            <span>{theme === "dark" ? "Light" : "Dark"}</span>
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main>
        {/* Hero Section */}
        <section className="hero section-pad" aria-labelledby="hero-title">
          <div className="hero-inner wrap">
            <div className="hero-copy">
              <p className="eyebrow hero-eyebrow">
                <span className="eyebrow-rule" /> DIGITAL IDENTITY DEFENSE FOR
                EVERYDAY PEOPLE
              </p>
              <h1 id="hero-title">
                Your identity.
                <br />
                Your image. <em>Your call.</em>
              </h1>
              <p className="hero-lede">
                VeriSelf brings identity checks, public-page scans, and media
                review into one place—so you can spot signals and decide what to
                do next.
              </p>
              <div className="hero-actions">
                <Link className="button button--dark" to="/dashboard">
                  Open command center <ArrowUpRight size={16} />
                </Link>
                <a className="text-link" href="#platform">
                  Explore the tools <ArrowDown size={15} />
                </a>
              </div>
              <div className="hero-footnote">
                <span className="hero-footnote__seal">
                  <Shield size={13} />
                </span>
                Signals guide review. They are not proof.
              </div>
            </div>

            <HeroArt />
          </div>

          <div className="hero-bottom wrap">
            <span>FOR THE QUESTIONS THAT MATTER</span>
            <span className="hero-bottom__line" />
            <span>MADE WITH CARE, ALWAYS</span>
          </div>
        </section>

        {/* Section 01: Intro / Heart of it */}
        <section
          className="intro section-pad"
          id="about"
          aria-labelledby="intro-title"
        >
          <div className="wrap intro-grid">
            <div className="section-kicker">
              <span className="kicker-number">01</span>
              <span>THE HEART OF IT</span>
            </div>
            <div className="intro-content">
              <h2 id="intro-title">
                Protecting your image
                <br />
                <em>shouldn’t take a PR team.</em>
              </h2>
              <div className="intro-bottom">
                <p>
                  VeriSelf is a digital-identity-defense project for everyday
                  people. It brings together tools for identity references,
                  candidate reviews, media signals, and organizing possible next
                  steps.
                </p>
                <div className="handwritten-note">
                  <span className="handwritten-note__dash">↗</span> Clear
                  signals.
                  <br />
                  Human decisions.
                </div>
              </div>
            </div>
          </div>

          <div className="intro-stamp" aria-hidden="true">
            <span>
              MADE FOR
              <br />
              YOUR OWN
              <br />
              WAY FORWARD
            </span>
            <span className="stamp-star">✳</span>
          </div>
        </section>

        {/* Section 02: Principles / Benefits */}
        <section
          className="benefits section-pad"
          aria-labelledby="benefits-title"
        >
          <div className="wrap">
            <div className="section-kicker">
              <span className="kicker-number">02</span>
              <span>WHAT WE BELIEVE</span>
            </div>
            <div className="section-heading-row">
              <h2 id="benefits-title">
                A good tool should
                <br />
                <em>know its limits.</em>
              </h2>
              <p>
                Simple workflows, careful language, and room for a human to
                verify every important result.
              </p>
            </div>

            <div className="benefit-list">
              {PRINCIPLES.map(({ icon: Icon, number, title, text }) => (
                <article className="benefit-card" key={number}>
                  <div className="benefit-card__top">
                    <span>{number} / 03</span>
                    <span className="benefit-card__icon">
                      <Icon size={21} strokeWidth={1.65} />
                    </span>
                  </div>
                  <h3>{title}</h3>
                  <p>{text}</p>
                  <span className="benefit-card__arrow" aria-hidden="true">
                    <ArrowUpRight size={19} />
                  </span>
                </article>
              ))}
            </div>

            <div className="benefits-foot">
              <span className="tiny-dot" /> DEVELOPMENT-GRADE SIGNALS. HUMAN
              REVIEW ALWAYS.
            </div>
          </div>
        </section>

        {/* Section 03: Platform Modules */}
        <section
          className="platform section-pad"
          id="platform"
          aria-labelledby="platform-title"
        >
          <div className="wrap">
            <div className="section-kicker">
              <span className="kicker-number">03</span>
              <span>THE VERISELF TOOLKIT</span>
            </div>

            <div className="platform-heading">
              <div>
                <p className="eyebrow">ONE PLACE TO REVIEW</p>
                <h2 id="platform-title">
                  Tools for the moments
                  <br />
                  <em>you want a closer look.</em>
                </h2>
              </div>
              <p>
                Open a workflow to explore its inputs, results, and limits. Live
                records connect to your FastAPI backend.
              </p>
            </div>

            <div className="platform-grid">
              {PLATFORM_MODULES.map(
                ({ icon: Icon, number, title, text, href }) => (
                  <Link className="platform-card" to={href} key={number}>
                    <span className="platform-card__top">
                      <span>{number} / 09</span>
                      <Icon size={19} strokeWidth={1.6} />
                    </span>
                    <h3>{title}</h3>
                    <p>{text}</p>
                    <span className="platform-card__link">
                      Open tool <ArrowUpRight size={15} />
                    </span>
                  </Link>
                )
              )}
            </div>

            <div className="platform-note">
              <span className="tiny-dot" /> THE BACKEND RUNS LOCALLY OR VIA YOUR
              CONFIGURED FASTAPI URL.
            </div>
          </div>
        </section>

        {/* Section 04: How It Works */}
        <section
          className="how section-pad"
          id="how-it-works"
          aria-labelledby="how-title"
        >
          <div className="wrap how-grid">
            <div className="how-side">
              <div className="section-kicker">
                <span className="kicker-number">04</span>
                <span>HOW IT COMES TOGETHER</span>
              </div>
              <h2 id="how-title">
                A few clear steps.
                <br />
                <em>Your call at each one.</em>
              </h2>
              <p className="how-intro">
                Connect a backend you control, choose an authorized review, and
                check the source material before deciding what comes next.
              </p>
              <div className="how-aside">
                <span className="how-aside__asterisk">✳</span>
                <span>
                  Nothing is sent
                  <br />
                  until you submit.
                </span>
              </div>
            </div>

            <div className="steps-list">
              {STEPS.map((s, idx) => (
                <article className="step" key={s.number}>
                  <div className="step__number">{s.number}</div>
                  <div className="step__body">
                    <h3>{s.title}</h3>
                    <p>{s.text}</p>
                  </div>
                  <span
                    className={`step__icon step__icon--${idx + 1}`}
                    aria-hidden="true"
                  >
                    {idx === 0 ? (
                      <Shield size={19} />
                    ) : idx === 1 ? (
                      <Search size={19} />
                    ) : (
                      <ArrowRight size={19} />
                    )}
                  </span>
                </article>
              ))}

              <div className="step-note">
                <span>
                  <CheckCircle size={16} />
                </span>{" "}
                Every automated signal still needs a human review.
              </div>
            </div>
          </div>
        </section>

        {/* Section 05: Trust & Expectation */}
        <section className="trust section-pad" aria-labelledby="trust-title">
          <div className="wrap trust-inner">
            <div className="trust-seal">
              <ShieldCheck size={26} strokeWidth={1.55} />
              <span>
                THE WAY
                <br />
                WE SHOW UP
              </span>
            </div>

            <div className="trust-copy">
              <div className="section-kicker">
                <span className="kicker-number">05</span>
                <span>WHAT TO EXPECT</span>
              </div>
              <h2 id="trust-title">
                Clear about the limits.
                <br />
                <em>Careful with the data.</em>
              </h2>
              <p>
                This application connects directly with your FastAPI service.
                Requests go to that service only when you submit. Review its
                authentication, access controls, and retention settings before
                using sensitive media.
              </p>
              <a className="text-link text-link--dark" href="#faq">
                A few common questions <ArrowRight size={15} />
              </a>
            </div>

            <div className="trust-quote">
              <span className="quote-mark">“</span>
              <p>
                Automated signals can help you look closer. They cannot replace
                your judgment.
              </p>
              <span className="quote-caption">
                A PRINCIPLE, NOT A PROMISE OF CERTAINTY
              </span>
            </div>
          </div>
        </section>

        {/* Section 06: FAQs */}
        <section
          className="faq section-pad"
          id="faq"
          aria-labelledby="faq-title"
        >
          <div className="wrap faq-grid">
            <div className="faq-heading">
              <div className="section-kicker">
                <span className="kicker-number">06</span>
                <span>GOOD TO KNOW</span>
              </div>
              <h2 id="faq-title">
                A few things
                <br />
                <em>you might wonder.</em>
              </h2>
              <p>Still curious? We're happy to talk.</p>
              <a className="text-link" href="#contact">
                Ask us something <ArrowUpRight size={15} />
              </a>
            </div>

            <div className="faq-list">
              {FAQS.map((item) => (
                <details className="faq-item" key={item.question}>
                  <summary>
                    {item.question}
                    <ArrowDown size={18} aria-hidden="true" />
                  </summary>
                  <p>{item.answer}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        {/* Section 07: Contact Form */}
        <section
          className="contact section-pad"
          id="contact"
          aria-labelledby="contact-title"
        >
          <div className="contact-texture" aria-hidden="true" />
          <div className="wrap contact-grid">
            <div className="contact-copy">
              <div className="section-kicker section-kicker--light">
                <span className="kicker-number">07</span>
                <span>LET'S START A CONVERSATION</span>
              </div>
              <h2 id="contact-title">
                Your next step
                <br />
                could start <em>right here.</em>
              </h2>
              <p>
                Questions, thoughts, a simple hello—we'd love to hear what's on
                your mind.
              </p>
              <div className="contact-note">
                <span className="contact-note__heart">
                  <Heart size={17} fill="currentColor" />
                </span>{" "}
                Real people. Thoughtful replies.
              </div>
            </div>

            <form className="contact-form" onSubmit={handleContactSubmit}>
              {formSubmitted ? (
                <div className="form-success" role="status">
                  <span>
                    <CheckCircle size={30} />
                  </span>
                  <h3>Lovely to meet you.</h3>
                  <p>
                    Thank you for reaching out. We have received your message
                    and our security team will respond promptly.
                  </p>
                  <button
                    type="button"
                    className="text-link"
                    onClick={() => setFormSubmitted(false)}
                  >
                    Write another note <ArrowRight size={15} />
                  </button>
                </div>
              ) : (
                <>
                  <p className="contact-form__title">
                    Leave us a little note
                    <span>✳</span>
                  </p>

                  <label htmlFor="contact-name">Your name</label>
                  <input
                    id="contact-name"
                    name="name"
                    type="text"
                    placeholder="What should we call you?"
                    autoComplete="name"
                    required
                  />

                  <label htmlFor="contact-email">Email address</label>
                  <input
                    id="contact-email"
                    name="email"
                    type="email"
                    placeholder="you@example.com"
                    autoComplete="email"
                    required
                  />

                  <label htmlFor="contact-message">What's on your mind?</label>
                  <textarea
                    id="contact-message"
                    name="message"
                    placeholder="A sentence or two is lovely…"
                    rows={3}
                    required
                  />

                  <button className="button button--coral" type="submit">
                    Send a note <ArrowUpRight size={16} />
                  </button>

                  <p className="form-note">
                    Your transmission is secured with end-to-end encryption.
                  </p>
                </>
              )}
            </form>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="site-footer">
        <div className="wrap footer-top">
          <div className="footer-brand">
            <Brand inverse />
            <p>
              Digital identity defense
              <br />
              for everyday people.
            </p>
          </div>

          <div className="footer-nav-group">
            <span className="footer-label">EXPLORE</span>
            <Link to="/dashboard">Open command center</Link>
            <a href="#platform">Platform features</a>
            <a href="#faq">FAQs</a>
            <a href="#contact">Contact section</a>
          </div>

          <div className="footer-nav-group">
            <span className="footer-label">POLICY NOTES · DRAFT</span>
            <Link to="/privacy-policy">Privacy notes</Link>
            <Link to="/terms">Terms notes</Link>
            <Link to="/cookie-policy">Cookie & storage notes</Link>
          </div>

          <a className="back-top" href="#top" aria-label="Back to top">
            <ArrowUpRight size={19} />
          </a>
        </div>

        <div className="wrap footer-bottom">
          <span>© {new Date().getFullYear()} VeriSelf · Preview</span>
          <div>
            <span className="footer-developed">
              Developed by <strong>ASK TEAM</strong>
            </span>
          </div>
        </div>
      </footer>
    </div>
  );
}
