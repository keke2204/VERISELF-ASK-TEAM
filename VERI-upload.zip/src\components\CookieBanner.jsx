/**
 * CookieBanner — shows on first visit, saves consent to localStorage.
 * Only essential cookies are used. No tracking cookies are set regardless
 * of whether the user accepts or declines.
 */
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "react-router-dom";

const CONSENT_KEY = "cookie_consent";

export default function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(CONSENT_KEY);
    if (!stored) {
      // Show after a short delay so it doesn't flash on load
      const t = setTimeout(() => setVisible(true), 1200);
      return () => clearTimeout(t);
    }
  }, []);

  const accept = () => {
    localStorage.setItem(CONSENT_KEY, "accepted");
    setVisible(false);
  };

  const decline = () => {
    localStorage.setItem(CONSENT_KEY, "declined");
    setVisible(false);
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ y: 120, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 120, opacity: 0 }}
          transition={{ type: "spring", damping: 22, stiffness: 260 }}
          role="dialog"
          aria-label="Cookie consent"
          aria-live="polite"
          style={{
            position: "fixed",
            bottom: "1.5rem",
            left: "50%",
            transform: "translateX(-50%)",
            zIndex: 9999,
            width: "min(95vw, 560px)",
            background: "var(--surface, #1a1a2e)",
            border: "1px solid var(--border, rgba(255,255,255,0.1))",
            borderRadius: "14px",
            padding: "1.25rem 1.5rem",
            boxShadow: "0 16px 40px rgba(0,0,0,0.5)",
            backdropFilter: "blur(12px)",
          }}
        >
          <div style={{ marginBottom: "0.75rem" }}>
            <strong style={{ fontSize: "1rem" }}>🍪 Cookie Notice</strong>
          </div>
          <p style={{ fontSize: "0.875rem", color: "var(--text-muted, #aaa)", marginBottom: "1rem", lineHeight: 1.5 }}>
            We use only <strong>essential cookies</strong> to keep the app running.
            No tracking, no ads, no third-party profiling. Read our{" "}
            <Link to="/cookie-policy" style={{ color: "var(--accent, #7c3aed)" }}>
              Cookie Policy
            </Link>{" "}
            and{" "}
            <Link to="/privacy-policy" style={{ color: "var(--accent, #7c3aed)" }}>
              Privacy Policy
            </Link>
            .
          </p>
          <div style={{ display: "flex", gap: "0.75rem", flexWrap: "wrap" }}>
            <button
              onClick={accept}
              style={{
                flex: 1,
                minWidth: 120,
                padding: "0.55rem 1rem",
                borderRadius: "8px",
                background: "var(--accent, #7c3aed)",
                color: "#fff",
                border: "none",
                cursor: "pointer",
                fontWeight: 600,
                fontSize: "0.875rem",
              }}
            >
              Accept Essential
            </button>
            <button
              onClick={decline}
              style={{
                flex: 1,
                minWidth: 120,
                padding: "0.55rem 1rem",
                borderRadius: "8px",
                background: "transparent",
                color: "var(--text-muted, #aaa)",
                border: "1px solid var(--border, rgba(255,255,255,0.15))",
                cursor: "pointer",
                fontSize: "0.875rem",
              }}
            >
              Decline
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
