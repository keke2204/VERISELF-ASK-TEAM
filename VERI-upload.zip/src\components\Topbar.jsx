import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { ShieldCheck, Sun, Moon, Home as HomeIcon } from "lucide-react";
import { useLocation, Link } from "react-router-dom";

const pageTitles = {
  "/dashboard": {
    title: "Command Center Overview",
    subtitle: "Real-time biometric threat surveillance and exposure index",
  },
  "/identity": {
    title: "Digital Identity Enrollment",
    subtitle: "Facial vector embedding and cryptographic reference baseline",
  },
  "/monitoring": {
    title: "Public Web Scans",
    subtitle: "Automated candidate asset scraping and endpoint probes",
  },
  "/matches": {
    title: "Candidate Match Engine",
    subtitle: "pHash cross-correlation and facial landmark verification",
  },
  "/manipulation": {
    title: "Deepfake Forensics Laboratory",
    subtitle: "Fourier frequency analysis, noise consistency & artifact detection",
  },
  "/risk": {
    title: "Identity Risk Assessment",
    subtitle: "Multimodal vulnerability scoring and exposure hierarchy",
  },
  "/alerts": {
    title: "Security Threat Alerts",
    subtitle: "Automated triage, incident status, and intervention feeds",
  },
  "/evidence": {
    title: "Cryptographic Evidence Vault",
    subtitle: "Immutable forensic logs with SHA-256 integrity proofs",
  },
  "/legal": {
    title: "Legal Response Generator",
    subtitle: "Statutory infringement documentation & legal response drafts",
  },
  "/protection": {
    title: "Image Signature & Provenance",
    subtitle: "Invisible signature verification and adversarial media shielding",
  },
};

export default function Topbar() {
  const location = useLocation();
  const current = pageTitles[location.pathname] || {
    title: "Identity Command Center",
    subtitle: "Protecting biometric presence across the open web",
  };

  const [theme, setTheme] = useState(() => {
    try {
      return localStorage.getItem("veriself-theme") || "light";
    } catch {
      return "light";
    }
  });

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    try {
      localStorage.setItem("veriself-theme", theme);
    } catch {
      // ignore
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === "dark" ? "light" : "dark"));
  };

  return (
    <motion.header
      className="topbar"
      initial={{ y: -15, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <div>
        <div className="topbar-title flex items-center gap-2">
          <span>{current.title}</span>
        </div>
        <div className="topbar-subtitle">{current.subtitle}</div>
      </div>

      <div className="flex items-center gap-3">
        <Link
          to="/"
          className="button-secondary"
          style={{
            fontSize: "12px",
            minHeight: "34px",
            padding: "0 12px",
            gap: "6px",
            textDecoration: "none",
          }}
          title="Return to Landing Page"
        >
          <HomeIcon size={14} />
          <span>Landing Page</span>
        </Link>

        <button
          className="theme-toggle"
          type="button"
          aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
          onClick={toggleTheme}
          style={{ minHeight: "34px", marginLeft: 0 }}
        >
          {theme === "dark" ? <Sun size={15} /> : <Moon size={15} />}
          <span>{theme === "dark" ? "Light" : "Dark"}</span>
        </button>

        <motion.div
          className="system-status"
          whileHover={{ scale: 1.02 }}
          transition={{ type: "spring", stiffness: 400 }}
        >
          <span className="status-dot" />
          <ShieldCheck size={14} strokeWidth={2.2} />
          <span>SURVEILLANCE ACTIVE</span>
        </motion.div>
      </div>
    </motion.header>
  );
}
