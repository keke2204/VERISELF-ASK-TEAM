const API_BASE = (
  import.meta.env.VITE_API_BASE ||
  (import.meta.env.DEV
    ? "http://127.0.0.1:8000"
    : "https://veriself-ask-team-api.onrender.com")
).replace(/\/$/, "");

async function request(endpoint, options = {}) {
  const headers = new Headers(options.headers || {});
  let response;

  try {
    response = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers,
      signal: options.signal,
    });
  } catch (error) {
    if (error.name === "AbortError") throw error;
    throw new Error(
      "Unable to reach the VeriSelf API. Check VITE_API_BASE and confirm the backend is online."
    );
  }

  const contentType = response.headers.get("content-type") || "";
  const data = contentType.includes("application/json")
    ? await response.json().catch(() => null)
    : null;

  if (!response.ok) {
    let message = `API request failed: ${response.status}`;
    if (typeof data?.detail === "string") message = data.detail;
    else if (data?.detail) message = JSON.stringify(data.detail);
    throw new Error(message);
  }
  return data;
}

async function warmApi() {
  try {
    await fetch(`${API_BASE}/health`, { cache: "no-store" });
  } catch {
    // The real request below provides the user-facing error if the service is unavailable.
  }
}

export const getHealth = () => request("/health");
export const registerIdentity = async (formData) => {
  await warmApi();
  return request("/identity/register", { method: "POST", body: formData });
};
export const verifyIdentity = async (formData) => {
  await warmApi();
  return request("/identity/verify", { method: "POST", body: formData });
};
export const analyzeImage = async (formData) => {
  await warmApi();
  return request("/manipulation/analyze-image", { method: "POST", body: formData });
};
export const analyzeVideo = async (formData) => {
  await warmApi();
  return request("/manipulation/analyze-video", { method: "POST", body: formData });
};
export const getMonitoringTargets = (userId) => request(`/monitoring/targets/${userId}`);
export const createMonitoringTarget = (userId, targetUrl) => request("/monitoring/targets", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ user_id: Number(userId), target_url: targetUrl }) });
export const scanMonitoringTarget = (targetId) => request(`/monitoring/targets/${targetId}/scan`, { method: "POST" });
export const getMonitoringResults = (targetId) => request(`/monitoring/results/${targetId}`);
export const verifyMatch = (identityId, candidateUrl, authorized = false) => request("/matches/verify", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ identity_id: Number(identityId), candidate_url: candidateUrl, authorized }) });
export const getMatchHistory = (identityId) => request(`/matches/history/${identityId}`);
export const assessRisk = (matchId) => request(`/risk/assess/${matchId}`, { method: "POST" });
export const getFindings = (identityId) => request(`/risk/findings/${identityId}`);
export const getRiskSummary = (identityId) => request(`/risk/summary/${identityId}`);
export const getAlerts = (identityId) => request(`/alerts/${identityId}`);
export const updateAlertStatus = (alertId, status) => request(`/alerts/${alertId}/status`, { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status: status.toUpperCase() }) });
export const getEvidence = (identityId) => request(`/evidence/${identityId}`);
export const generateLegalNotice = (findingId) => request(`/legal-response/generate/${findingId}`, { method: "POST" });
export const getLegalResponses = (identityId) => request(`/legal-response/${identityId}`);
export const protectMedia = (formData) => request("/protection/protect", { method: "POST", body: formData });
export const verifyProtectedMedia = (formData) => request("/protection/verify", { method: "POST", body: formData });
export const getProtectionHistory = (identityId) => request(`/protection/history/${identityId}`);
export async function downloadProtectedMedia(protectionId) {
  const response = await fetch(`${API_BASE}/protection/download/${protectionId}`);
  if (!response.ok) throw new Error(`Unable to download protected media: ${response.status}`);
  return response.blob();
}
export { API_BASE };
